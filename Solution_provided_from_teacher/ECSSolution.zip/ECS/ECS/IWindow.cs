﻿namespace ECS
{
    // Interface for a window
    public interface IWindow
    {
        void Close();
        void Open();
    }
}